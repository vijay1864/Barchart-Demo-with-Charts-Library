//
//  ViewController.swift
//  BarChartDemo
//
//  Created by Intellisense on 24/08/19.
//  Copyright © 2019 Intellisense. All rights reserved.
//

import UIKit
import Charts

class ViewController: UIViewController, ChartViewDelegate {

    
    @IBOutlet weak var barChartView: BarChartView!
    weak var axisFormatDelegate: IAxisValueFormatter?
    
    var months: [String]!
    var unitsSold = [Double]()
    
    //   let months: [String]  = ["Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul"]
    //    let unitsSold : [Double]  = [20.0, 54.0, 6.0, 30.0, 92.0, 16.0,114.0]
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        barChartView.delegate = self
        axisFormatDelegate = self
        months  = ["Mon", "Tue", "Wed", "Thu", "Fri", "Sat", "Sun"]
        unitsSold  = [20.0, 54.0, 6.0, 30.0, 92.0, 16.0,114.0]
        setChart(dataPoints: months, values: unitsSold)
        
        
    }
    func setChart(dataPoints: [String], values: [Double]) {
        
        barChartView.noDataText = "You need to provide data for the chart."
        //        var dataEntries: [BarChartDataEntry] = []
        //
        //        for i in 0..<dataPoints.count {
        //            let dataEntry = BarChartDataEntry(x: Double(i), y: values[i], data: months as AnyObject )
        //
        //            dataEntries.append(dataEntry)
        //        }
        //
        
        // Prevent from setting an empty data set to the chart (crashes)
        guard dataPoints.count > 0 else { return }
        
        var dataEntries = [BarChartDataEntry]()
        
        for i in 0..<dataPoints.count {
            let entry = BarChartDataEntry(x: Double(i), y: values[i], data: months as AnyObject?)
            dataEntries.append(entry)
            
            //            let format:BarChartFormatter = BarChartFormatter()
            //            let xaxis:XAxis = XAxis()
            //            xaxis.valueFormatter = format
            //            format.stringForValue(Double(i), axis: xaxis)
            //            barChartView.xAxis.valueFormatter = xaxis.valueFormatter
            
        }
        
        let chartDataSet = BarChartDataSet(entries: dataEntries, label: "Units Sold")
        chartDataSet.drawValuesEnabled = false
        chartDataSet.colors = [UIColor.red]
        chartDataSet.colors = [UIColor.lightGray]
        chartDataSet.highlightColor = UIColor.orange.withAlphaComponent(0.3)
        chartDataSet.highlightAlpha = 1
        let chartData = BarChartData(dataSet: chartDataSet)
        barChartView.data = chartData
        let xAxisValue = barChartView.xAxis
        xAxisValue.valueFormatter = axisFormatDelegate
        
        //   chartDataSet.colors = ChartColorTemplates.colorful()    //multiple colors
        
        //Animation bars
        barChartView.animate(xAxisDuration: 0.0, yAxisDuration: 1.0, easingOption: .easeInCubic)
        
        // X axis configurations
        barChartView.xAxis.granularityEnabled = true
        barChartView.xAxis.granularity = 1
        barChartView.xAxis.drawAxisLineEnabled = true
        barChartView.xAxis.drawGridLinesEnabled = false
        barChartView.xAxis.labelFont = UIFont.systemFont(ofSize: 15.0)
        barChartView.xAxis.labelTextColor = UIColor.black
        barChartView.xAxis.labelPosition = .bottom
        
        // Right axis configurations
        barChartView.rightAxis.drawAxisLineEnabled = false
        barChartView.rightAxis.drawGridLinesEnabled = false
        barChartView.rightAxis.drawLabelsEnabled = false
        
        // Other configurations
        barChartView.highlightPerDragEnabled = false
        barChartView.chartDescription?.text = ""
        barChartView.legend.enabled = false
        barChartView.pinchZoomEnabled = false
        barChartView.doubleTapToZoomEnabled = false
        barChartView.scaleYEnabled = false
        
        barChartView.drawMarkers = true
        
        let l = barChartView.legend
        l.horizontalAlignment = .left
        l.verticalAlignment = .bottom
        l.orientation = .horizontal
        l.drawInside = false
        l.form = .circle
        l.formSize = 9
        l.font = UIFont(name: "HelveticaNeue-Light", size: 11)!
        l.xEntrySpace = 4
        
        // On tapped bar marker  before add BalloonMarker.swift
        
        let marker =  BalloonMarker(color: UIColor.orange, font: UIFont.boldSystemFont(ofSize: 13), textColor: UIColor.white, insets: UIEdgeInsets(top: 7.0, left: 7.0, bottom: 15.0, right: 7.0))
        marker.chartView = barChartView
        barChartView.marker = marker
        
        
    }
    
    //    @objc(BarChartFormatter)
    //    public class BarChartFormatter: NSObject, IAxisValueFormatter{
    //
    //        var months: [String]! = ["Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul"]
    //
    //        public func stringForValue(_ value: Double, axis: AxisBase?) -> String {
    //
    //            return months[Int(value)]
    //        }
    //    }
}
extension ViewController: IAxisValueFormatter {
    
    func stringForValue(_ value: Double, axis: AxisBase?) -> String {
        return months[Int(value)]
    }
}

//MARK :  steps
/*
 
 1.install pod file
 2.Assign barchartview class to chart view in storyboad
 3.follow setchart() method
 4.for ballon marker add BallonMarker.swift file to your project library    for this file chartsDemo->Components-> BallonMarker.swift
 
 */



